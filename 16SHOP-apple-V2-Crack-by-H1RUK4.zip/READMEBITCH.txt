[+] ------------------------ 16Shop Apple Scampage V.2.0.1 ------------------------ [+]
[+] Configure Setting Email Result and Other Setting available on file setting.ini
[+] Set on  = input "on"
[+] Set off = just blank ""
[+] Admin Panel to view visitor/bin/bank logs you can login after extract the script in https://yourscam.com/admin
[+] Email for Admin Panel : admin@izanami.apps
[+] Password for Admin Panel : izanami666
[+] For lifetime scampage you can set on all of [ BLOCKER AND ENC SETTING ] in setting.ini
[+] If u have problem ? ICQ @hiruka404
[+] ------------------------ 16Shop Apple Scampage V.2.0.1 ------------------------ [+]