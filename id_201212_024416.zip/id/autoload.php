<?php
error_reporting(0);
require_once('killbot.php');
require_once('config.php');

$Killbot = new Killbot;

if($config['bot_block']){
	$checkbot 	= $Killbot->checkBot($config['apikey']);
	$json 		= $Killbot->json($checkbot);

	if($json['data']['block_access']) {
		die(header("Location: ".$config['redirect_bot']));
	}
}

if(preg_match("/YOUR_APIKEY/", $config['apikey'])){
	$Killbot->error('self_notification', '<font style="color:red">ERROR - Pleas edit files config.php and replace \'YOUR_APIKEY\' with your apikey.</font>');
}