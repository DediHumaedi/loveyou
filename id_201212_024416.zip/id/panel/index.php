<?php
error_reporting(0);
session_start();

require_once('../killbot.php');
require_once('../config.php');

$Killbot = new Killbot;

if(preg_match("/YOUR_APIKEY/", $config['apikey']) ){
	$Killbot->error('self_notification', '<font style="color:red">ERROR - Pleas edit files config.php and replace \'YOUR_APIKEY\' with your apikey.</font>');
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- disable all search engine index robot -->
	
	<link href="https://killbot.org/files/images/favicon.png" rel="shortcut icon">

    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet" />
    <link rel="stylesheet" href="https://bootswatch.com/4/darkly/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@3/dark.css">
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.js"></script>
</head>
<body>
	<?php 
		if($_GET['cookies'] == 'delete'):
		session_destroy(); 
	?>
	<script type="text/javascript">
		Swal.fire({
			icon: 'success',
			title: 'Log Out',
			text: 'Cookies has been delete successfully',
		}).then((result) => {
			if (result.value) {
				window.location.href="../panel";
			}
		})
	</script>
	<?php endif;?>

	<?php
		if(isset($_POST['username']) && isset($_POST['password']) && $_POST['password'] == $config['password_panel'] && $_POST['username'] == $config['username_panel']):
		$_SESSION['login'] = true;
	?>
	<script type="text/javascript">
		Swal.fire({
			icon: 'success',
			title: 'Login Succes',
			text: 'Session has been created successfully',
		})
	</script>
	<?php endif;?>

	<?php if($_GET['message'] == 'success'): ?>
	<?php elseif($_GET['message'] == 'error'): ?>
	<?php endif;?>

	<?php if($_SESSION['login'] == false): ?>
	<title>Killbot - Login</title>
	<div class="container mt-5 mb-5">
        <div class="d-flex justify-content-center mb-2">
            <h1>K I L L <span class="text-danger">B O T</span></h1>
        </div>
        <div class="d-flex justify-content-center">
			<div class="card col-md-6">
				<div class="card-body">
					<form action="" method="post" class="mb-3">
						<h4>💎 Login</h4>
						<div class="form-group mt-3">
							<input type="text" name="username" class="form-control" placeholder="Username" autocomplete="off" required>
						</div>
						<div class="form-group mt-3">
							<input type="password" name="password" class="form-control" placeholder="Password" autocomplete="off" required>
						</div>
						<input value="Login" type="submit" class="btn btn-block btn-outline-danger" id="submit" />
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php else: ?>
	<title>Killbot - Dashboard</title>
	<div class="container mt-5 mb-5">
		<div class="row">
			<div class="col-md-12">
				<h1>K I L L <span class="text-danger">B O T</span></h1>
				<small>Real Visitor Detection Manager | Version: 1.0.2 | Full Manage at <a target="_blank" href="https://killbot.org/dashboard" class="text-danger">https://killbot.org/dashboard</a></small>
				<hr>
			</div>
			<div class="col-md-12 text-right">
				<div class="form-group">
					<a target="_blank" href="https://killbot.org/dashboard" type="button" class="btn btn-outline-warning">👋 Full Manage</a>
					<a href="../panel/?cookies=delete" class="btn btn-outline-danger">🔥 Logout</a>
				</div>
			</div>
		</div>
        <div class="d-flex justify-content-center">
			<div class="card col-md-12">
				<div class="card-body">
					<form method="post" class="mb-3">
						<h4>🚀 Generate Shortlink</h4>
						<hr>
						<div class="form-group mt-3">
							<label for="inputEmail4">URL / Domain</label>
							<input type="text" name="url" id="url" class="form-control" placeholder="https://google.com" autocomplete="off" required>
						</div>
						<p><i>Shortlink will generate with default configuration. To set type blocker / type device / level blocker / change url. please go to <a target="_blank" href="https://killbot.org/shortlink" class="text-danger">https://killbot.org/shortlink</a></i></p>
						<input value="Generate" type="button" onclick="GenerateURL()" class="btn btn-block btn-outline-danger" id="submit" />
					</form>
				</div>
			</div>
		</div>
		<br>
        <div class="d-flex justify-content-center">
			<div class="card col-md-12">
				<div class="card-body">
					<h4>📖 List Shortlink</h4>
					<hr>
					<table id="data-domain" class="table table-striped table-bordered table-condensed table-hover">
                        <thead>
							<tr>
                                <th>KEYNAME</th>
                                <th>URL SHORTLINK</th>
								<th>VISITOR REDIRECTION</th>
							</tr>
                            </thead>
                            <tbody>
							</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	
	<script src="//code.jquery.com/jquery-1.4.4.min.js"></script>
	<script>
        GetAllShortlink();
        function loadTable(tableId, fields, data) {
			var hostme = '<?=str_replace('/panel/', '', $Killbot->getBaseUrl());?>/r/';
            var rows = '';
            $.each(data, function(index, item) {
				var row = '<tr>';
				$.each(fields, function(index, field) {
					row += '<td>' + item[field + ''] + '</td>';
					if(item[field + ''].length == 7){
						row += '<td>' + hostme + item[field + ''] + '</td>';
					}
				});
				rows += row + '<tr>';
            });
            $('#' + tableId + ' tbody').html(rows);
		}
		function isValidUrl(string) {
			try {
				new URL(string);
			} catch (_) {
				return false;  
			}
			return true;
		}
        function GetAllShortlink(){ 
			$.get("https://killbot.org/api/v2/shortlink/list?apikey=<?=$config['apikey'];?>", function(data) {
				loadTable('data-domain', ['keyname','url'], data.data.list);
			});
        }
        function GenerateURL(){
			var url = document.getElementById("url").value;
			if(isValidUrl(url)) {
				$.get("https://killbot.org/api/v2/shortlink/generate?apikey=<?=$config['apikey'];?>&url="+url, function(data) {
					if(data.meta.code == 200){
						Swal.fire({
							icon: 'success',
							title: 'Success',
							text: data.meta.message,
						}).then((result) => {
							if (result.value) {
								window.location.href="../panel";
							}
						})
					} else {
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Failed to create shortlink. Something when wrong!',
						})
					}
				});
			} else {
				Swal.fire({
					icon: 'error',
					title: 'Oops...',
					text: 'Invalid parameter URL / Domain!',
				})
			}
		}
	</script>
	<?php endif;?>
</body>
</html>